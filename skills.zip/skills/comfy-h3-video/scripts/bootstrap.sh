#!/usr/bin/env bash
# Install/verify comfy-cli + comfy-mcp and print grok mcp add command.
set -euo pipefail
PYTHON="${PYTHON:-python3}"
COMFY_DIR="${1:-}"

echo "Installing comfy-mcp and comfy-cli…"
"$PYTHON" -m pip install -U "comfy-mcp" "comfy-cli>=1.14.0"

SCRIPTS="$("$PYTHON" -c "import sysconfig; print(sysconfig.get_path('scripts'))")"
COMFY="$SCRIPTS/comfy"
MCP="$SCRIPTS/comfy-mcp"

echo "comfy:     $COMFY"
echo "comfy-mcp: $MCP"

if [[ -n "$COMFY_DIR" ]]; then
  "$COMFY" set-default "$COMFY_DIR"
fi

echo
echo "Register MCP (restart Grok CLI after this):"
echo "  grok mcp add comfy-mcp -e COMFY_BIN=\"$COMFY\" -- \"$MCP\""
echo
echo "Then: grok mcp doctor comfy-mcp"
echo "Start ComfyUI with your GPU flags before generating."
