# Install/verify comfy-cli + comfy-mcp and print grok mcp add command.
# Usage: powershell -File bootstrap.ps1 [-Python python] [-ComfyDir C:\path\to\ComfyUI]
param(
  [string]$Python = "python",
  [string]$ComfyDir = ""
)

$ErrorActionPreference = "Stop"
Write-Host "Installing comfy-mcp and comfy-cli…"
& $Python -m pip install -U "comfy-mcp" "comfy-cli>=1.14.0"

$scripts = & $Python -c "import sysconfig; print(sysconfig.get_path('scripts'))"
$comfy = Join-Path $scripts "comfy.exe"
if (-not (Test-Path $comfy)) { $comfy = Join-Path $scripts "comfy" }
$mcp = Join-Path $scripts "comfy-mcp.exe"
if (-not (Test-Path $mcp)) { $mcp = Join-Path $scripts "comfy-mcp" }

Write-Host "comfy:     $comfy"
Write-Host "comfy-mcp: $mcp"

if ($ComfyDir -ne "") {
  & $comfy set-default $ComfyDir
}

Write-Host ""
Write-Host "Register MCP (restart Grok CLI after this):"
Write-Host "  grok mcp add comfy-mcp -e COMFY_BIN=`"$comfy`" -- `"$mcp`""
Write-Host ""
Write-Host "Then: grok mcp doctor comfy-mcp"
Write-Host "Start ComfyUI with your GPU flags before generating (e.g. --cuda-device 1)."
