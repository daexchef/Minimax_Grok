---
name: comfy-h3-video
description: >
  Install/check local ComfyUI, comfy-cli, and comfy-mcp, wire them into Grok CLI,
  then generate MiniMax H3 videos through Comfy MCP (official T2V/I2V templates,
  last-frame 30s extend, or clone a proven 6-clip long graph for ~90s). Use when
  the user wants ComfyUI MCP setup, generate a video, MiniMax H3, long chain,
  UGC clip, /comfy-h3-video, or /comfy-h3-setup.
metadata:
  short-description: Comfy MCP setup + H3 video generation
argument-hint: "[setup | generate <idea>]"
compatibility: Requires Python 3.10+, local ComfyUI, NVIDIA GPU recommended
---

# ComfyUI MCP + MiniMax H3 video

Local ComfyUI only (`127.0.0.1:8188` by default). Never Comfy Cloud unless the user explicitly agrees to spend credits on an `API`-tagged template.

Discover MCP tools with `search_tool` before `use_tool`. Qualified names look like `comfy-mcp__server_info`.

## Setup (run this first, or when MCP/Comfy is missing)

1. Python 3.10+ on PATH.
2. Install engines (user-approved shell):
   `python -m pip install -U "comfy-mcp" "comfy-cli>=1.14.0"`
3. Locate binaries (`comfy`, `comfy-mcp`). On Windows they often live in `Scripts\` next to Python.
4. If no ComfyUI workspace: `comfy install` or `comfy set-default <existing-ComfyUI-dir>`.
5. Register MCP with Grok (adjust paths):
   `grok mcp add comfy-mcp -e COMFY_BIN=<abs-path-to-comfy> -- <abs-path-to-comfy-mcp>`
   Then tell the user to **restart the Grok session** so tools attach.
6. Call `comfy-mcp__server_info`. If `server.running` is false, start ComfyUI:
   - Prefer the user's existing launcher (CUDA device flags matter).
   - Or `comfy-mcp__launch_comfyui` with extras they already use (e.g. `--cuda-device 1`).
   - Do not pass non-loopback `--listen` without explicit confirmation.
7. Call `comfy-mcp__system_stats`. Trust **this** for the live GPU (`devices[].name`, `vram_*`, `system.argv`). `server_info.hardware` can show the wrong GPU on multi-GPU (e.g. laptop 3070 vs eGPU).
8. Stop and report: URL, workspace, GPU, VRAM, whether H3 weights exist (`search_models` / `models/diffusion_models`). Do not download multi-GB weights unless the user agrees.

If `search_tool` finds no `comfy-mcp` tools after pip install, MCP is not attached — restart Grok; do not fake tool calls.

## Generate

### RAM / GPU discipline

H3 stages ~15–20 GB in **system RAM**. Before a 6-clip long graph, `comfy-mcp__free_memory` (unload models) and wait **5 minutes** if the last job was heavy or RAM free is under ~8 GB. One long graph at a time. Never queue four 6-clip jobs.

### Pick a path

| Ask | Path |
|---|---|
| ≤15s, no existing long JSON | Official **`video_minimax_h3_t2v`** (exclude API). I2V sibling: **`video_minimax_h3_i2v`**. |
| ~30s | T2V 15s → last frame → I2V 15s → concat, drop first frame of clip 2. |
| ~90s / 1.5–2 min | Clone a **proven 6-clip H3 long JSON** the user already ran. Do not invent a new graph. |
| HTML studio | User's `Long_Video_Workflow_Studio.html` / `MiniMax_H3_Long_Workflow_Generator.html` writes JSON; then `run_workflow` on that file. |

### Official template loop

1. `search_templates` with `exclude_api=true`.
2. `get_template` / `fetch_template` to a user-owned path. Read `local_check.get("runnable")`. If `checked: false`, `validate_workflow`. If not runnable, tell them what is missing (`install_node` only with consent).
3. `list_workflow_slots` then `set_workflow_slot` (`stdout: false` to write). Typical H3 T2V: prompt, duration seconds (`140/133.value` or the slot named duration), turbo flags if present, `16:9`, ~0.4 megapixels, filename prefix.
4. `validate_workflow` — `valid: true` is required, not sufficient.
5. `run_workflow(wait=False)`. Poll `job` with **≤180s** waits (longer waits can false-fail `server_not_running` while Comfy is still sampling). Then `fetch_outputs`.
6. Paid/`API` templates: `confirm_spend=true` only after the user agrees.

### 30s last-frame extend

1. Extract last video frame to `ComfyUI/input/`.
2. Fetch `video_minimax_h3_i2v`, set LoadImage to that file, duration ~15s, continuation prompt (see Prompt grammar).
3. Concat videos; skip clip 2 frame 0.

### Clone 6-clip long graph (~90s)

Source: a JSON that **already completed** on this install (shared UNET/CLIP/VAEs, EasyCache, Sage, per-clip `MiniMaxH3ImageToVideo`, last-frame handoff, 1-frame trim, AudioConcat).

Clone it. Change only: six prompts, width/height (safe default **864×480**), length **362** (15s @ 24fps on H3 17k+5 grid), matching trim lengths **361**, save prefixes, unlink clip-1 `first_frame` for T2V. Do not redesign nodes.

`validate_workflow` → `run_workflow(wait=False)` → poll. After completion: `free_memory`, wait 5 minutes before the next long job.

### Prompt grammar

```
integrated_multimodal_description: …
overall_soundscape: …
non_diegetic_music: …
tracking/camera notes: …
```

Clips 2+ start with: continue seamlessly from the first frame; same people/wardrobe/light/camera/audio; no reset, no cut, no fade.

### After a run

Give the mp4 path (usually `ComfyUI/output/video/…`) and the `http://127.0.0.1:8188/view?…` URL. Say which path you used (template vs clone).
