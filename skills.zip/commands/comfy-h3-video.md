---
description: Generate a local ComfyUI MiniMax H3 video via MCP (template, last-frame extend, or cloned long graph).
argument-hint: "[duration and idea]"
---

Run the **comfy-h3-video** skill in **generate** mode.

User request: $ARGUMENTS

If Comfy MCP is missing or ComfyUI is down, run setup first, then generate.
