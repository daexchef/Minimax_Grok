---
description: Install or verify ComfyUI, comfy-cli, comfy-mcp, and Grok MCP wiring, then confirm a local server is reachable.
argument-hint: "[comfy workspace path]"
---

Run the **comfy-h3-video** skill in **setup** mode.

If `$ARGUMENTS` is a path, treat it as the ComfyUI workspace (`comfy set-default`).

Do not generate a video in this command. Stop after MCP `server_info` + `system_stats` are healthy, or after telling the user exactly what they must install.
