# Grok CLI plugin: ComfyUI MCP + MiniMax H3 video

Drop-in package so **Grok CLI** can (1) check/install **ComfyUI + comfy-mcp**, then (2) **direct local video generation** the way we did: official H3 templates, last-frame 30s extend, or clone a proven 6-clip long graph for ~90s.

This does **not** download 20 GB weights or replace your ComfyUI install. It wires Grok to **your** local server.

## What other people install

Copy this folder, or clone the repo that contains `grok-comfy-h3-video/`.

### Option A — Grok plugin (MCP + skills + slash commands)

```bash
grok plugin install /path/to/grok-comfy-h3-video --trust
```

Enable it if it stays off (`grok plugin list`, then enable, or Plugins tab). **Restart Grok.**

If `comfy-mcp` is not on PATH, run bootstrap (below) then:

```bash
grok mcp add comfy-mcp -e COMFY_BIN="C:\path\to\comfy.exe" -- "C:\path\to\comfy-mcp.exe"
```

### Option B — Skill only (no plugin)

Copy `skills/comfy-h3-video/` to `~/.grok/skills/comfy-h3-video/`.

### Option C — Bootstrap then chat

```powershell
powershell -File skills/comfy-h3-video/scripts/bootstrap.ps1 -ComfyDir C:\path\to\ComfyUI
```

```bash
bash skills/comfy-h3-video/scripts/bootstrap.sh /path/to/ComfyUI
```

Restart Grok. In a new session:

```
/comfy-h3-setup
/comfy-h3-video  15 second night walk in the rain, MiniMax H3
```

Or naturally: “set up Comfy MCP” / “make a 90s video about …”

## What Grok will do

1. `server_info` then `system_stats` (trust live GPU, not always `comfy env`).
2. **≤15s:** gallery `video_minimax_h3_t2v` (non-API).
3. **~30s:** T2V → last frame → I2V → concat, drop duplicate first frame.
4. **~90s:** clone a **6-clip H3 JSON that already ran on that machine**; one job at a time; unload + **5 min pause** between long jobs (H3 stages ~20 GB RAM).

Paid `API` templates stay off unless the user agrees to spend.

## Requirements on their machine

- Python 3.10+
- NVIDIA GPU (16 GB VRAM comfortable for 864×480 H3 15s clips)
- ComfyUI workspace with MiniMax H3 weights if they want H3 (UNET + text encoder + video/audio VAEs)
- Grok CLI with MCP enabled

## Slash commands

| Command | Action |
|---|---|
| `/comfy-h3-setup` | Install/check Comfy + MCP only |
| `/comfy-h3-video` | Generate (runs setup first if MCP is missing) |
